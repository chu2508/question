import React from "react";
import './Head.css'

function Head() {
  return (
    <div className="header">
      <header>Header</header>
    </div>
  );
}

export default Head;
