import React from "react"

export const SectionGroup: React.FC = (props) => <div>{props.children}</div>
