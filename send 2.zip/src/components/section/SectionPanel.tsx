import React from "react"

export const SectionPanel: React.FC = (props) => <div>{props.children}</div>
